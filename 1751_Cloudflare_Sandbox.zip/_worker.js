var __defProp = Object.defineProperty;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });

// ../.local/functions/index.js
var __defProp2 = Object.defineProperty;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __name2 = /* @__PURE__ */ __name((target, value) => __defProp2(target, "name", { value, configurable: true }), "__name");
var __esm = /* @__PURE__ */ __name((fn, res, err) => /* @__PURE__ */ __name(function __init() {
  if (err) throw err[0];
  try {
    return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
  } catch (e) {
    throw err = [e], e;
  }
}, "__init"), "__esm");
var __export = /* @__PURE__ */ __name((target, all) => {
  for (var name in all)
    __defProp2(target, name, { get: all[name], enumerable: true });
}, "__export");
var ENTITIES;
var init_admin_model = __esm({
  "../shared/admin-model.js"() {
    init_functionsRoutes_0_7395176389100484();
    ENTITIES = {
      products: { permission: "products", fields: { title: "text", description: "body", category_id: "uuid?", price_minor: "price", product_type: ["digital", "physical", "course"], image_url: "url?", status: ["draft", "published", "unavailable"], featured: "nonnegative" } },
      categories: { permission: "products", fields: { name: "text" } },
      promotions: { permission: "products", fields: { code: "code", percent: "percent", expires_at: "datetime", max_uses: "positive", active: "boolean", minimum_minor: "nonnegative" } },
      product_assets: { permission: "products", fields: { product_id: "uuid", storage_path: "path", download_limit: "positive?" } },
      summits: { permission: "events", fields: { title: "text", description: "body", starts_on: "date", ends_on: "date", timezone: "text", published: "boolean" } },
      sessions: { permission: "events", fields: { summit_id: "uuid", title: "text", description: "body", starts_at: "datetime", ends_at: "datetime", category: "text?", location: "text?", meeting_url: "url?", capacity: "positive?", waitlist_enabled: "boolean", registration_closes_at: "datetime", registration_open: "boolean", published: "boolean", price_minor: "nonnegative", cancellation_allowed: "boolean" } },
      speakers: { permission: "events", fields: { name: "text", bio: "body", image_url: "url?" } },
      communities: { permission: "community", fields: { name: "text", description: "body", visibility: ["public", "members"], join_open: "boolean", published: "boolean" } },
      community_categories: { permission: "community", fields: { community_id: "uuid", name: "text" } },
      articles: { permission: "content", fields: { slug: "slug", title: "text", category: "text", excerpt: "body", body: "body", cover_image: "url?", author: "text", published_at: "datetime?", reading_minutes: "positive", status: ["draft", "published"] } },
      legal_policies: { permission: "settings", fields: { slug: ["privacy", "terms", "cookies", "refunds", "digital-delivery", "community-guidelines", "event-terms"], title: "text", body: "body", approved: "boolean" } },
      inquiries: { permission: "inquiries", fields: { status: ["new", "in_review", "contacted", "resolved"], internal_notes: "body", assigned_to: "uuid?", follow_up_at: "datetime?" } }
    };
  }
});
function validateData(entity, data) {
  const schema = ENTITIES[entity];
  if (!schema || !data || typeof data !== "object" || Array.isArray(data)) error("invalid_entity");
  const result = {};
  for (const [key, value] of Object.entries(data)) {
    let type = schema.fields[key];
    if (!type) error("invalid_field");
    if (Array.isArray(type)) {
      result[key] = option(value, type);
      continue;
    }
    const nullable = type.endsWith("?");
    type = type.replace("?", "");
    if (nullable && (value === null || value === "")) {
      result[key] = null;
      continue;
    }
    if (type === "uuid") result[key] = id(value);
    else if (type === "boolean") {
      if (typeof value !== "boolean") error("invalid_input");
      result[key] = value;
    } else if (["price", "positive", "nonnegative", "percent"].includes(type)) {
      if (!Number.isSafeInteger(value) || value < (type === "nonnegative" ? 0 : 1) || value > (type === "percent" ? 90 : 2e9)) error("invalid_number");
      result[key] = value;
    } else if (type === "datetime" || type === "date") {
      if (typeof value !== "string" || !Number.isFinite(Date.parse(value)) || type === "date" && !/^\d{4}-\d{2}-\d{2}$/.test(value)) error("invalid_date");
      result[key] = value;
    } else if (type === "url") result[key] = safeUrl(value);
    else if (type === "path") {
      result[key] = text(value, 1, 250);
      if (!/^[A-Za-z0-9_./-]+$/.test(value) || value.startsWith("/") || value.split("/").includes("..")) error("invalid_path");
    } else if (type === "code") {
      result[key] = text(value, 1, 50).toUpperCase();
      if (!/^[A-Z0-9_-]+$/.test(result[key])) error("invalid_input");
    } else if (type === "slug") {
      result[key] = text(value, 1, 100);
      if (!/^[a-z0-9]+(-[a-z0-9]+)*$/.test(value)) error("invalid_slug");
    } else result[key] = text(value, nullable || type === "body" ? 0 : 1, type === "body" ? 5e4 : 250);
  }
  if (entity === "articles" && result.status === "published") {
    if (!result.title?.trim() || !result.author?.trim() || !result.body?.trim()) error("incomplete_content");
    result.published_at ||= (/* @__PURE__ */ new Date()).toISOString();
  }
  return result;
}
__name(validateData, "validateData");
function safeUrl(value) {
  if (/^assets\/img\d+\.webp$/.test(value)) return value;
  try {
    const u = new URL(text(value, 1, 1500));
    if (u.protocol !== "https:" || u.username || u.password) error("invalid_url");
    return u.href;
  } catch {
    error("invalid_url");
  }
}
__name(safeUrl, "safeUrl");
function validatedClaims(bearer) {
  try {
    const part = bearer.split(".")[1].replace(/-/g, "+").replace(/_/g, "/");
    return JSON.parse(atob(part));
  } catch {
    return {};
  }
}
__name(validatedClaims, "validatedClaims");
function isMfa(claims) {
  return claims.aal === "aal2";
}
__name(isMfa, "isMfa");
function requireRecentMfa(claims) {
  const times = (claims.amr || []).filter((x) => ["totp", "mfa/totp"].includes(x.method)).map((x) => Number(x.timestamp));
  const latest = Math.max(...times), now = Date.now() / 1e3;
  if (!isMfa(claims) || !Number.isFinite(latest) || now - latest > 900 || latest > now + 60) error("recent_mfa_required", 403);
}
__name(requireRecentMfa, "requireRecentMfa");
function createAdminDatabase(env, fetcher) {
  return async (action, p, actor, mfa) => {
    const { response, data } = await fetchJson(fetcher, `${supabase(env)}/rest/v1/rpc/platform_admin`, { method: "POST", headers: { apikey: env.SUPABASE_SERVICE_ROLE_KEY, Authorization: `Bearer ${env.SUPABASE_SERVICE_ROLE_KEY}`, "Content-Type": "application/json" }, body: JSON.stringify({ action, p, actor, mfa }) }, "database_unavailable");
    if (!response.ok) {
      const allowed = /* @__PURE__ */ new Set(["unauthorized", "forbidden", "mfa_required", "account_suspended", "not_found", "edit_conflict", "invalid_entity", "invalid_field", "invalid_date_range", "capacity_below_reserved", "schedule_outside_summit", "invalid_schedule", "invalid_timezone", "scan_required", "last_super_admin", "confirmation_required", "refund_exists", "capacity_full", "paid_cancellation_requires_review", "retention_approval_required", "invalid_fulfillment", "session_revoked", "archived_readonly", "product_file_required", "existing_sessions_outside_summit", "staff_deletion_requires_role_review", "deletion_request_required", "identity_deletion_unverified"]);
      const code = allowed.has(data.message) ? data.message : "database_error";
      error(code, code === "unauthorized" || code === "session_revoked" ? 401 : ["forbidden", "mfa_required", "account_suspended"].includes(code) ? 403 : code === "database_error" ? 503 : 409);
    }
    return data;
  };
}
__name(createAdminDatabase, "createAdminDatabase");
function validateSetting(key, value) {
  const type = SETTINGS[key];
  if (!type) error("invalid_setting");
  if (value === null && !["retention", "boolean", "origin"].includes(type)) return null;
  if (type === "retention") {
    if (!value || !Number.isInteger(value.financial_days) || value.financial_days < 1 || value.financial_days > 3650 || typeof value.retain_purchase_access !== "boolean") error("owner_retention_policy_required");
    return { financial_days: value.financial_days, retain_purchase_access: value.retain_purchase_access };
  }
  if (type === "boolean") {
    if (typeof value !== "boolean") error("invalid_input");
    return value;
  }
  if (type === "email") return email(value);
  if (type === "url") return safeUrl(value);
  if (type === "origin") {
    const u = new URL(safeUrl(value));
    if (u.pathname !== "/" || u.search || u.hash) error("invalid_origin");
    return u.origin;
  }
  if (type === "ids") {
    if (!Array.isArray(value) || value.length > 12) error("invalid_input");
    return value.map(id);
  }
  if (type === "urls") {
    if (!Array.isArray(value) || value.length > 3) error("invalid_input");
    return value.map(safeUrl);
  }
  if (type === "links") {
    if (!Array.isArray(value) || value.length > 8) error("invalid_input");
    return value.map((v) => ({ label: text(v.label, 1, 60), url: safeUrl(v.url) }));
  }
  if (type === "ecosystem") {
    if (!value || Array.isArray(value) || typeof value !== "object" || Object.keys(value).some((k) => !["Yolena", "Store", "Community", "Compound Interest Summit", "Services", "Stories"].includes(k))) error("invalid_input");
    return Object.fromEntries(Object.entries(value).map(([k, v]) => [k, text(v, 1, 600)]));
  }
  return text(value, 0, type === "body" ? 3e3 : 200);
}
__name(validateSetting, "validateSetting");
async function handleAdmin({ route, b, request, env, fetcher, db, adminDb, session, cookieHeaders, requestId }) {
  const actor = session.user?.id;
  if (!session.user?.email_confirmed_at) error("unauthorized", 401);
  const claims = validatedClaims(session.bearer), mfa = isMfa(claims);
  const run = /* @__PURE__ */ __name2((action2, p = {}) => adminDb(action2, { ...p, request_id: requestId }, actor, mfa), "run");
  if (route === "admin/context") return run("context");
  if (route.startsWith("admin/mfa/")) {
    await run("context");
    if (route === "admin/mfa/factors") {
      const u = await authCall(env, fetcher, "user", "GET", null, session.bearer);
      return { factors: (u.factors || []).map((f) => ({ id: f.id, factor_type: f.factor_type, status: f.status, friendly_name: f.friendly_name })) };
    }
    if (request.method !== "POST") error("method_not_allowed", 405);
    if (route === "admin/mfa/enroll") {
      const factor = await authCall(env, fetcher, "factors", "POST", { factor_type: "totp", friendly_name: "1751 administration" }, session.bearer);
      return { id: factor.id, secret: factor.totp?.secret, uri: factor.totp?.uri };
    }
    if (route === "admin/mfa/challenge") return authCall(env, fetcher, `factors/${id(b.factor_id)}/challenge`, "POST", {}, session.bearer);
    if (route === "admin/mfa/verify") {
      if (!/^\d{6}$/.test(b.code || "")) error("invalid_mfa_code");
      const s = await authCall(env, fetcher, `factors/${id(b.factor_id)}/verify`, "POST", { challenge_id: id(b.challenge_id), code: b.code }, session.bearer);
      const { sessionCookies: sessionCookies2 } = await Promise.resolve().then(() => (init_api(), api_exports));
      cookieHeaders.splice(0, cookieHeaders.length, ...sessionCookies2(s, env));
      const c = validatedClaims(s.access_token);
      if (!isMfa(c)) error("mfa_required", 403);
      await adminDb("context", { request_id: requestId }, actor, true);
      await adminDb("access_log", { request_id: requestId }, actor, true);
      return { verified: true };
    }
    error("not_found", 404);
  }
  await run("context");
  if (!mfa) error("mfa_required", 403);
  const action = route.replace("admin/", "");
  const highSettings = ["maintenance", "retention_approved", "retention_rules", "site_origin"];
  if (["roles", "user_control", "refund_prepare", "deletion_review", "delete_account"].includes(action) || action === "setting_save" && highSettings.includes(b.key) || action === "settings_batch" && b.updates?.some((v) => highSettings.includes(v.key))) requireRecentMfa(claims);
  if (request.method === "GET") {
    const readActions = ["overview", "analytics", "list", "detail", "revisions", "orders", "order_detail", "registrations", "reports", "posts", "memberships", "users", "user_detail", "deletions", "subscribers", "settings", "policies", "health", "audit", "incidents", "media"];
    if (action === "export") return exportCsv(run, b);
    if (!readActions.includes(action)) error("method_not_allowed", 405);
    if (["list", "detail", "revisions"].includes(action) && !ENTITIES[b.entity]) error("invalid_entity");
    const data = await run(action, b);
    if (action === "health") return { ...data, integrations: Object.fromEntries(["SUPABASE_URL", "PAYSTACK_SECRET_KEY", "RESEND_API_KEY", "SCANNER_URL", "OPS_INBOX"].map((k) => [k, { configured: !!env[k], verification: "Not independently verified by presence alone" }])) };
    return data;
  }
  if (action === "save") {
    const data = validateData(b.entity, b.data);
    if (b.entity === "legal_policies" && data.approved) {
      requireRecentMfa(claims);
      if (b.confirmation !== "APPROVE POLICY") error("confirmation_required", 409);
    }
    return run("save", { entity: b.entity, id: b.id || null, data, expected_updated_at: b.expected_updated_at || null });
  }
  if (action === "archive") return run("archive", { entity: option(b.entity, ["products", "articles", "summits", "communities"]), id: id(b.id) });
  if (action === "setting_save") return run("setting_save", { key: b.key, value: validateSetting(b.key, b.value), confirmation: b.confirmation });
  if (action === "settings_batch") {
    if (!Array.isArray(b.updates) || b.updates.length > 20) error("invalid_input");
    return run("settings_batch", { updates: b.updates.map((v) => ({ key: v.key, value: validateSetting(v.key, v.value) })), confirmation: b.confirmation });
  }
  if (action === "roles") {
    if (!Array.isArray(b.roles) || b.roles.length > 6) error("invalid_input");
    return run("roles", { user_id: id(b.user_id), roles: [...new Set(b.roles.map((r) => option(r, ["super_admin", "admin", "editor", "event_manager", "store_manager", "moderator"])))], confirmation: b.confirmation });
  }
  if (action === "user_control") return run(action, { user_id: id(b.user_id), ...typeof b.suspended === "boolean" ? { suspended: b.suspended } : {}, reason: text(b.reason, 5, 1e3) });
  if (action === "deletion_review") return run(action, { user_id: id(b.user_id), note: text(b.note, 10, 2e3), confirmation: b.confirmation });
  if (action === "delete_account") {
    const op = await run("delete_prepare", { user_id: id(b.user_id), key: id(b.key), note: text(b.note, 10, 2e3), confirmation: b.confirmation });
    if (op.status === "completed") return { completed: true };
    let response;
    try {
      response = await fetcher(`${supabase(env)}/auth/v1/admin/users/${b.user_id}`, { method: "DELETE", headers: { Authorization: `Bearer ${env.SUPABASE_SERVICE_ROLE_KEY}`, apikey: env.SUPABASE_SERVICE_ROLE_KEY }, signal: AbortSignal.timeout(15e3) });
    } catch {
      error("identity_deletion_requires_reconciliation", 409);
    }
    if (!response.ok && response.status !== 404) error("identity_deletion_requires_reconciliation", 409);
    return run("delete_complete", { id: op.id });
  }
  if (action === "session_cancel") return run(action, { id: id(b.id), reason: text(b.reason, 5, 1e3), confirmation: b.confirmation });
  if (action === "session_speakers") {
    if (!Array.isArray(b.speaker_ids) || b.speaker_ids.length > 20) error("invalid_input");
    return run(action, { session_id: id(b.session_id), speaker_ids: [...new Set(b.speaker_ids.map(id))] });
  }
  if (action === "registration_action") return run(action, { id: id(b.id), operation: option(b.operation, ["check_in", "promote", "cancel"]) });
  if (action === "moderate") return run(action, { id: id(b.id), decision: option(b.decision, ["hide", "dismiss"]), note: text(b.note || "", 0, 2e3) });
  if (action === "post_moderate") return run(action, { id: id(b.id), ...Object.fromEntries(["hidden", "featured", "announcement"].filter((k) => typeof b[k] === "boolean").map((k) => [k, b[k]])) });
  if (action === "restriction") return run(action, { community_id: id(b.community_id), user_id: id(b.user_id), reason: text(b.reason, 5, 1e3), until: b.until ? new Date(b.until).toISOString() : null });
  if (action === "unsubscribe") return run(action, { id: id(b.id) });
  if (action === "order_resolve") return run(action, { reference: text(b.reference, 5, 100), reason: text(b.reason, 5, 1e3) });
  if (action === "order_reconcile") {
    await run(action, { reference: text(b.reference, 5, 100), reason: "Staff requested authoritative provider verification" });
    return verifyPayment(b.reference, env, fetcher, db);
  }
  if (action === "refund_prepare") {
    const prepared = await run(action, { reference: text(b.reference, 5, 100), key: id(b.key), reason: text(b.reason, 5, 1e3), confirmation: b.confirmation });
    if (prepared.status !== "requested") return prepared;
    await run("refund_result", { id: prepared.id, status: "uncertain" });
    try {
      const refund = await paystack(env, fetcher, "refund", { transaction: b.reference, merchant_note: b.reason });
      if (!refund?.id) throw new ApiError("payment_provider_rejected", 502);
      return run("refund_result", { id: prepared.id, status: "submitted", provider_id: String(refund.id) });
    } catch {
      error("refund_requires_reconciliation", 409);
    }
  }
  if (action === "incident_resolve" || action === "outbox_retry") return run(action, { id: id(b.id) });
  error("not_found", 404);
}
__name(handleAdmin, "handleAdmin");
function csvCell(value) {
  const s = typeof value === "object" ? JSON.stringify(value) : String(value ?? "");
  return '"' + (/^[\s]*[=+\-@]/.test(s) ? "'" + s : s).replace(/"/g, '""') + '"';
}
__name(csvCell, "csvCell");
async function exportCsv(run, b) {
  const action = option(b.entity, ["orders", "registrations", "subscribers", "users", "inquiries"]);
  const rows = [];
  for (let offset = 0; offset <= 5e3; offset += 100) {
    const result = await run(action === "inquiries" ? "list" : action, { ...b, entity: action, offset, limit: 100, ...action === "subscribers" ? { status: "subscribed" } : {} });
    const batch = result.rows || [];
    if (rows.length + batch.length > 5e3) error("export_too_large", 409);
    rows.push(...batch);
    if (batch.length < 100) break;
  }
  const columns = action === "orders" ? ["reference", "customer_name", "email", "total_minor", "currency", "status", "created_at"] : action === "registrations" ? ["reference", "name", "email", "session_title", "status", "checked_in_at", "created_at"] : action === "subscribers" ? ["email", "status", "consent_at", "confirmed_at"] : action === "users" ? ["id", "email", "display_name", "created_at", "suspended"] : ["reference", "name", "email", "inquiry_type", "status", "created_at"];
  return new Response([columns.map(csvCell).join(","), ...rows.map((row) => columns.map((k) => csvCell(row[k])).join(","))].join("\r\n"), { headers: { "Content-Type": "text/csv; charset=utf-8", "Content-Disposition": `attachment; filename="1751-${action}.csv"`, "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff", "X-Robots-Tag": "noindex" } });
}
__name(exportCsv, "exportCsv");
var error;
var SETTINGS;
var init_admin = __esm({
  "../backend/admin.js"() {
    init_functionsRoutes_0_7395176389100484();
    init_api();
    init_admin_model();
    error = /* @__PURE__ */ __name2((code, status = 400) => {
      throw new ApiError(code, status);
    }, "error");
    __name2(validateData, "validateData");
    __name2(safeUrl, "safeUrl");
    __name2(validatedClaims, "validatedClaims");
    __name2(isMfa, "isMfa");
    __name2(requireRecentMfa, "requireRecentMfa");
    __name2(createAdminDatabase, "createAdminDatabase");
    SETTINGS = { retention_rules: "retention", site_name: "text", contact_email: "email", contact_details: "body", announcement: "body", hero_title: "text", hero_intro: "body", summit_intro: "body", service_intro: "body", logo_url: "url", hero_images: "urls", social_links: "links", footer_links: "links", ecosystem_descriptions: "ecosystem", featured_products: "ids", featured_stories: "ids", maintenance: "boolean", retention_approved: "boolean", site_origin: "origin" };
    __name2(validateSetting, "validateSetting");
    __name2(handleAdmin, "handleAdmin");
    __name2(csvCell, "csvCell");
    __name2(exportCsv, "exportCsv");
  }
});
function inspectFile(bytes, kind) {
  if (!(bytes instanceof Uint8Array) || bytes.length === 0 || bytes.length > (kind === "image" ? 4194304 : 8388608)) fail("invalid_file_size");
  const text2 = new TextDecoder("latin1").decode(bytes.slice(0, 32));
  if (kind === "image") {
    if (bytes[0] === 255 && bytes[1] === 216 && bytes[2] === 255 && bytes.at(-2) === 255 && bytes.at(-1) === 217) return { contentType: "image/jpeg", ext: "jpg" };
    if (bytes.length > 24 && bytes.slice(0, 8).every((v, i) => v === [137, 80, 78, 71, 13, 10, 26, 10][i])) {
      const d = new DataView(bytes.buffer, bytes.byteOffset);
      const w = d.getUint32(16), h = d.getUint32(20);
      if (!w || !h || w * h > 16e6) fail("image_dimensions_exceeded");
      return { contentType: "image/png", ext: "png" };
    }
    if (text2.startsWith("RIFF") && text2.slice(8, 12) === "WEBP") return { contentType: "image/webp", ext: "webp" };
  } else {
    if (text2.startsWith("%PDF-")) return { contentType: "application/pdf", ext: "pdf" };
    if (bytes[0] === 80 && bytes[1] === 75 && [3, 5].includes(bytes[2]) && [4, 6].includes(bytes[3])) return { contentType: "application/zip", ext: "zip" };
  }
  fail("unsupported_file_type");
}
__name(inspectFile, "inspectFile");
async function scanDocument(bytes, sha256, env, fetcher) {
  if (!env.SCANNER_URL || !env.SCANNER_TOKEN) return "pending";
  let u;
  try {
    u = new URL(env.SCANNER_URL);
  } catch {
    fail("invalid_scanner_configuration");
  }
  if (u.protocol !== "https:" || u.username || u.password || u.search) fail("invalid_scanner_configuration");
  const { response, data } = await fetchJson(fetcher, u.href, { method: "POST", headers: { Authorization: `Bearer ${env.SCANNER_TOKEN}`, "Content-Type": "application/octet-stream", "X-Content-SHA256": sha256 }, body: bytes }, "scanner_unavailable");
  if (!response.ok || data.sha256 !== sha256 || !["clean", "rejected"].includes(data.verdict)) throw new ApiError("scanner_unavailable", 503);
  return data.verdict;
}
__name(scanDocument, "scanDocument");
async function boundedBinary(response) {
  const reader = response.body.getReader(), chunks = [];
  let size = 0;
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    size += value.length;
    if (size > 8388608) {
      await reader.cancel();
      fail("invalid_file_size");
    }
    chunks.push(value);
  }
  const bytes = new Uint8Array(size);
  let offset = 0;
  for (const chunk of chunks) {
    bytes.set(chunk, offset);
    offset += chunk.length;
  }
  return bytes;
}
__name(boundedBinary, "boundedBinary");
async function handleUpload({ route, b, request, env, fetcher, adminDb, session, requestId }) {
  if (request.method !== "POST") throw new ApiError("method_not_allowed", 405);
  const actor = session.user?.id;
  if (!session.user?.email_confirmed_at) throw new ApiError("unauthorized", 401);
  const mfa = isMfa(validatedClaims(session.bearer)), permission = route === "admin/scan" ? "products" : option(b.permission, ["products", "content", "events", "settings"]);
  const run = /* @__PURE__ */ __name2((action, p) => adminDb(action, { ...p, permission, request_id: requestId }, actor, mfa), "run");
  await run("media", { limit: 1 });
  let bytes, asset, kind, sha256;
  if (route === "admin/scan") {
    asset = await run("media_detail", { id: id(b.id) });
    if (!asset || asset.bucket !== "quarantine" || asset.kind !== "document") fail("invalid_media");
    kind = asset.kind;
    const r = await fetcher(`${supabase(env)}/storage/v1/object/authenticated/quarantine/${asset.storage_path}`, { headers: { Authorization: `Bearer ${env.SUPABASE_SERVICE_ROLE_KEY}` }, signal: AbortSignal.timeout(15e3) });
    if (!r.ok || Number(r.headers.get("Content-Length")) > 8388608) throw new ApiError("storage_unavailable", 502);
    bytes = await boundedBinary(r);
    inspectFile(bytes, kind);
  } else {
    kind = option(b.kind, ["image", "document"]);
    if (kind === "document" && permission !== "products") throw new ApiError("forbidden", 403);
    if (typeof b.base64 !== "string" || b.base64.length > 112e5 || !/^[A-Za-z0-9+/]*={0,2}$/.test(b.base64)) fail("invalid_file");
    try {
      bytes = Uint8Array.from(atob(b.base64), (c) => c.charCodeAt(0));
    } catch {
      fail("invalid_file");
    }
  }
  const type = inspectFile(bytes, kind);
  sha256 = [...new Uint8Array(await crypto.subtle.digest("SHA-256", bytes))].map((x) => x.toString(16).padStart(2, "0")).join("");
  if (asset && sha256 !== asset.sha256) fail("file_integrity_mismatch");
  const scan = kind === "document" ? await scanDocument(bytes, sha256, env, fetcher) : "clean";
  if (route === "admin/scan") {
    if (scan === "clean") {
      const { response: response2 } = await fetchJson(fetcher, `${supabase(env)}/storage/v1/object/move`, { method: "POST", headers: { Authorization: `Bearer ${env.SUPABASE_SERVICE_ROLE_KEY}`, "Content-Type": "application/json" }, body: JSON.stringify({ bucketId: "quarantine", sourceKey: asset.storage_path, destinationKey: asset.storage_path, destinationBucket: "digital-products" }) }, "storage_unavailable");
      if (!response2.ok) throw new ApiError("storage_unavailable", 502);
    }
    await run("media_scan", { id: asset.id, scan_status: scan, bucket: scan === "clean" ? "digital-products" : "quarantine" });
    return { id: asset.id, path: asset.storage_path, status: scan };
  }
  const mediaId = crypto.randomUUID(), path = `${mediaId}.${type.ext}`, bucket = kind === "image" ? "site-media" : scan === "clean" ? "digital-products" : "quarantine";
  const { response } = await fetchJson(fetcher, `${supabase(env)}/storage/v1/object/${bucket}/${path}`, { method: "POST", headers: { Authorization: `Bearer ${env.SUPABASE_SERVICE_ROLE_KEY}`, "Content-Type": type.contentType, "x-upsert": "false" }, body: bytes }, "storage_unavailable");
  if (!response.ok) throw new ApiError("storage_unavailable", 502);
  await run("media_record", { id: mediaId, path, bucket, kind, content_type: type.contentType, size: bytes.length, sha256, scan_status: scan });
  return { id: mediaId, path, status: scan, ...kind === "image" ? { url: `${supabase(env)}/storage/v1/object/public/site-media/${path}` } : {} };
}
__name(handleUpload, "handleUpload");
var fail;
var init_uploads = __esm({
  "../backend/uploads.js"() {
    init_functionsRoutes_0_7395176389100484();
    init_api();
    init_admin();
    fail = /* @__PURE__ */ __name2((code) => {
      throw new ApiError(code, 400);
    }, "fail");
    __name2(inspectFile, "inspectFile");
    __name2(scanDocument, "scanDocument");
    __name2(boundedBinary, "boundedBinary");
    __name2(handleUpload, "handleUpload");
  }
});
var api_exports = {};
__export(api_exports, {
  ApiError: /* @__PURE__ */ __name(() => ApiError, "ApiError"),
  authCall: /* @__PURE__ */ __name(() => authCall, "authCall"),
  createDatabase: /* @__PURE__ */ __name(() => createDatabase, "createDatabase"),
  email: /* @__PURE__ */ __name(() => email, "email"),
  equal: /* @__PURE__ */ __name(() => equal, "equal"),
  fetchJson: /* @__PURE__ */ __name(() => fetchJson, "fetchJson"),
  handleRequest: /* @__PURE__ */ __name(() => handleRequest, "handleRequest"),
  hash: /* @__PURE__ */ __name(() => hash, "hash"),
  hmac: /* @__PURE__ */ __name(() => hmac, "hmac"),
  id: /* @__PURE__ */ __name(() => id, "id"),
  option: /* @__PURE__ */ __name(() => option, "option"),
  paystack: /* @__PURE__ */ __name(() => paystack, "paystack"),
  renderEmail: /* @__PURE__ */ __name(() => renderEmail, "renderEmail"),
  sessionCookies: /* @__PURE__ */ __name(() => sessionCookies, "sessionCookies"),
  supabase: /* @__PURE__ */ __name(() => supabase, "supabase"),
  text: /* @__PURE__ */ __name(() => text, "text"),
  validateItems: /* @__PURE__ */ __name(() => validateItems, "validateItems"),
  verifyPayment: /* @__PURE__ */ __name(() => verifyPayment, "verifyPayment")
});
function text(value, min, max) {
  if (typeof value !== "string" || value.trim().length < min || value.trim().length > max || /[\u0000-\u0008\u000b\u000c\u000e-\u001f]/.test(value)) fail2("invalid_input");
  return value.trim();
}
__name(text, "text");
async function hmac(secret, value, algorithm = "SHA-256") {
  const key = await crypto.subtle.importKey("raw", encoder.encode(secret), { name: "HMAC", hash: algorithm }, false, ["sign"]);
  return hex(await crypto.subtle.sign("HMAC", key, encoder.encode(value)));
}
__name(hmac, "hmac");
function equal(a, b) {
  if (typeof a !== "string" || typeof b !== "string" || a.length !== b.length) return false;
  let difference = 0;
  for (let i = 0; i < a.length; i++) difference |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return difference === 0;
}
__name(equal, "equal");
function validateItems(items) {
  if (!Array.isArray(items) || !items.length || items.length > 50) fail2("invalid_cart");
  const seen = /* @__PURE__ */ new Set();
  return items.map((i) => {
    const productId = id(i.id);
    if (seen.has(productId) || !Number.isInteger(i.quantity) || i.quantity < 1 || i.quantity > 99) fail2("invalid_quantity");
    seen.add(productId);
    return { id: productId, quantity: i.quantity };
  }).sort((a, b) => a.id.localeCompare(b.id));
}
__name(validateItems, "validateItems");
function origin(env) {
  requireConfig(env, "APP_ORIGIN");
  const u = new URL(env.APP_ORIGIN);
  if (u.protocol !== "https:" && !(u.protocol === "http:" && ["localhost", "127.0.0.1"].includes(u.hostname))) fail2("invalid_server_configuration", 503);
  return u.origin;
}
__name(origin, "origin");
function checkMutation(request, env) {
  if (request.headers.get("Origin") !== origin(env) || request.headers.get("X-1751-Request") !== "1") fail2("csrf_rejected", 403);
  if (!request.headers.get("Content-Type")?.startsWith("application/json")) fail2("json_required", 415);
}
__name(checkMutation, "checkMutation");
async function readBody(request, limit = 2e4) {
  if (Number(request.headers.get("Content-Length")) > limit) fail2("request_too_large", 413);
  let size = 0;
  const chunks = [];
  if (!request.body) return "";
  const reader = request.body.getReader();
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    size += value.byteLength;
    if (size > limit) {
      await reader.cancel();
      fail2("request_too_large", 413);
    }
    chunks.push(value);
  }
  const all = new Uint8Array(size);
  let offset = 0;
  for (const chunk of chunks) {
    all.set(chunk, offset);
    offset += chunk.byteLength;
  }
  return new TextDecoder().decode(all);
}
__name(readBody, "readBody");
function parseBody(raw) {
  try {
    const b = JSON.parse(raw);
    if (!b || typeof b !== "object" || Array.isArray(b)) fail2("invalid_json");
    return b;
  } catch {
    fail2("invalid_json");
  }
}
__name(parseBody, "parseBody");
async function fetchJson(fetcher, url, init, errorCode = "upstream_unavailable") {
  let response;
  try {
    response = await fetcher(url, { ...init, signal: AbortSignal.timeout(15e3) });
  } catch {
    fail2(errorCode, 502);
  }
  let data;
  try {
    data = await response.json();
  } catch {
    fail2(errorCode, 502);
  }
  return { response, data };
}
__name(fetchJson, "fetchJson");
function supabase(env) {
  requireConfig(env, "SUPABASE_URL", "SUPABASE_SERVICE_ROLE_KEY");
  const u = new URL(env.SUPABASE_URL);
  if (u.protocol !== "https:" && !["localhost", "127.0.0.1"].includes(u.hostname)) fail2("invalid_server_configuration", 503);
  return u.origin;
}
__name(supabase, "supabase");
function createDatabase(env, fetcher) {
  return async (action, p = {}, actor = null) => {
    const { response, data } = await fetchJson(fetcher, `${supabase(env)}/rest/v1/rpc/platform`, {
      method: "POST",
      headers: { apikey: env.SUPABASE_SERVICE_ROLE_KEY, Authorization: `Bearer ${env.SUPABASE_SERVICE_ROLE_KEY}`, "Content-Type": "application/json" },
      body: JSON.stringify({ action, p, actor })
    }, "database_unavailable");
    if (!response.ok) {
      const code = dbCodes.has(data.message) ? data.message : "database_error";
      fail2(code, ["unauthorized", "session_revoked"].includes(code) ? 401 : ["forbidden", "mfa_required", "account_suspended"].includes(code) ? 403 : code === "not_found" ? 404 : ["database_error", "maintenance_mode"].includes(code) ? 503 : 409);
    }
    return data;
  };
}
__name(createDatabase, "createDatabase");
function cookies(request) {
  return Object.fromEntries((request.headers.get("Cookie") || "").split(";").map((c) => c.trim().split("=")).filter((x) => x.length === 2));
}
__name(cookies, "cookies");
function sessionCookies(session, env) {
  const secure = origin(env).startsWith("https:") ? "; Secure" : "";
  const common = `; Path=/api; HttpOnly; SameSite=Lax${secure}`;
  return [
    `s1751_access=${session?.access_token || ""}${common}; Max-Age=${session ? Math.min(session.expires_in || 3600, 3600) : 0}`,
    `s1751_refresh=${session?.refresh_token || ""}${common}; Max-Age=${session ? 2592e3 : 0}`
  ];
}
__name(sessionCookies, "sessionCookies");
async function authCall(env, fetcher, path, method, body, bearer) {
  requireConfig(env, "SUPABASE_ANON_KEY");
  const { response, data } = await fetchJson(fetcher, `${supabase(env)}/auth/v1/${path}`, {
    method,
    headers: { apikey: env.SUPABASE_ANON_KEY, "Content-Type": "application/json", ...bearer ? { Authorization: `Bearer ${bearer}` } : {} },
    ...body ? { body: JSON.stringify(body) } : {}
  }, "auth_unavailable");
  if (!response.ok) fail2(response.status === 429 ? "rate_limited" : "auth_rejected", response.status === 429 ? 429 : 401);
  return data;
}
__name(authCall, "authCall");
async function identity(request, env, fetcher) {
  const c = cookies(request);
  if (!c.s1751_access && !c.s1751_refresh) return { user: null, cookieHeaders: [] };
  if (c.s1751_access) {
    try {
      return { user: await authCall(env, fetcher, "user", "GET", null, c.s1751_access), bearer: c.s1751_access, cookieHeaders: [] };
    } catch (e) {
      if (e.code !== "auth_rejected") throw e;
    }
  }
  if (c.s1751_refresh) {
    try {
      const s = await authCall(env, fetcher, "token?grant_type=refresh_token", "POST", { refresh_token: c.s1751_refresh });
      return { user: s.user, bearer: s.access_token, cookieHeaders: sessionCookies(s, env) };
    } catch (e) {
      if (e.code !== "auth_rejected") throw e;
    }
  }
  return { user: null, cookieHeaders: sessionCookies(null, env) };
}
__name(identity, "identity");
function sandbox(env) {
  requireConfig(env, "PAYSTACK_SECRET_KEY", "APP_SECRET");
  if (!/^sk_test_[a-zA-Z0-9]+$/.test(env.PAYSTACK_SECRET_KEY) || env.APP_SECRET.length < 32) fail2("sandbox_configuration_required", 503);
}
__name(sandbox, "sandbox");
async function paystack(env, fetcher, path, body) {
  sandbox(env);
  const { response, data } = await fetchJson(fetcher, `https://api.paystack.co/${path}`, {
    method: body ? "POST" : "GET",
    headers: { Authorization: `Bearer ${env.PAYSTACK_SECRET_KEY}`, "Content-Type": "application/json" },
    ...body ? { body: JSON.stringify(body) } : {}
  }, "payment_provider_unavailable");
  if (!response.ok || data.status !== true) fail2("payment_provider_rejected", 502);
  return data.data;
}
__name(paystack, "paystack");
async function verifyPayment(reference, env, fetcher, db) {
  const transaction = await paystack(env, fetcher, `transaction/verify/${encodeURIComponent(reference)}`);
  if (transaction.reference !== reference || transaction.domain !== "test") fail2("payment_mismatch", 409);
  if (transaction.status !== "success") {
    if (["failed", "abandoned"].includes(transaction.status)) await db("payment_state", { reference, status: transaction.status === "failed" ? "failed" : "cancelled" });
    return { status: transaction.status === "failed" ? "failed" : transaction.status === "abandoned" ? "cancelled" : "pending" };
  }
  if (!Number.isSafeInteger(transaction.amount) || transaction.currency !== "NGN" || !transaction.id) fail2("payment_mismatch", 409);
  return db("finalize_payment", { reference, amount: transaction.amount, currency: transaction.currency, provider_id: String(transaction.id), order_url: `${origin(env)}/#account` });
}
__name(verifyPayment, "verifyPayment");
async function initializePayment(ord, env, fetcher, db) {
  if (ord.status === "paid") return ord;
  if (ord.status === "refunded") fail2("order_refunded", 409);
  if (ord.checkout_url) return ord;
  const payment = await paystack(env, fetcher, "transaction/initialize", { email: ord.email, amount: ord.total_minor, currency: "NGN", reference: ord.reference, callback_url: `${origin(env)}/#payment` });
  const u = new URL(payment.authorization_url);
  if (u.protocol !== "https:" || u.hostname !== "checkout.paystack.com") fail2("payment_provider_rejected", 502);
  await db("payment_url", { reference: ord.reference, url: u.href });
  return { ...ord, checkout_url: u.href };
}
__name(initializePayment, "initializePayment");
function renderEmail(template, d) {
  const link = /* @__PURE__ */ __name2((url, label) => `<p><a href="${escape(url)}">${escape(label)}</a></p>`, "link");
  if (template === "newsletter") return { subject: "Confirm your 1751 newsletter subscription", html: `<p>Please confirm your subscription within 24 hours.</p>${link(d.confirm_url, "Confirm subscription")}${link(d.unsubscribe_url, "Unsubscribe")}` };
  if (template === "order") return { subject: `1751 order ${d.reference}`, html: `<p>Payment verified for ${escape(d.reference)}. Total: NGN ${(d.total_minor / 100).toFixed(2)}.</p>${link(d.url, "View your order and downloads")}` };
  if (template === "registration") return { subject: `1751 registration ${d.reference}`, html: `<p>Registration ${escape(d.reference)}: ${escape(d.status || "confirmed")}.</p><p>${escape(d.title || "")} ${escape(d.starts_at || "")} ${escape(d.timezone || "")}</p><p>Open your account dashboard for event information, calendar download and cancellation rules.</p>` };
  if (template === "inquiry") return { subject: `1751 ${d.type} inquiry ${d.reference}`, html: `<p>${escape(d.name)} (${escape(d.email)}) \u2014 ${escape(d.organization)}</p><p>${escape(d.message)}</p><p>Preferred contact: ${escape(d.contact_method)} ${escape(d.phone)}. Budget: ${escape(d.budget)}</p>` };
  if (template === "deletion") return { subject: "1751 account deletion request", html: `<p>Review deletion request for user ${escape(d.user_id)} in the private database.</p>` };
  if (template === "schedule_update") return { subject: "1751 session schedule updated", html: `<p>${escape(d.title)} has a schedule update.</p><p>${escape(d.starts_at)} \u2013 ${escape(d.ends_at)} (${escape(d.timezone)}).</p><p>Your registration ${escape(d.reference)} is retained. Open your dashboard for current details.</p>` };
  if (template === "session_cancelled") return { subject: "1751 session cancelled", html: `<p>${escape(d.title)} has been cancelled.</p><p>${escape(d.reason)}</p><p>Reference: ${escape(d.reference)}. ${d.paid_review ? "Any payment requires the team refund workflow; this notice does not confirm a refund." : ""}</p>` };
  if (template === "operations_alert") return { subject: "1751 operations require attention", html: `<p>Review these redacted system checks in the admin health dashboard:</p><ul>${(d.issues || []).map((v) => `<li>${escape(v)}</li>`).join("")}</ul>` };
  fail2("invalid_email_template", 503);
}
__name(renderEmail, "renderEmail");
async function flushEmails(env, fetcher, db) {
  requireConfig(env, "RESEND_API_KEY", "EMAIL_FROM");
  const batch = await db("claim_emails");
  let sent = 0;
  for (const job of batch) {
    try {
      const { subject, html } = renderEmail(job.template, job.data);
      const { response, data } = await fetchJson(fetcher, "https://api.resend.com/emails", {
        method: "POST",
        headers: { Authorization: `Bearer ${env.RESEND_API_KEY}`, "Content-Type": "application/json", "Idempotency-Key": job.id },
        body: JSON.stringify({ from: env.EMAIL_FROM, to: [job.recipient], subject, html })
      }, "email_provider_unavailable");
      if (!response.ok || !data.id) fail2("email_provider_rejected", 502);
      await db("email_result", { id: job.id, sent: true });
      sent++;
    } catch {
      await db("email_result", { id: job.id, sent: false, error: "email_delivery_failed" });
    }
  }
  return { processed: batch.length, sent, failed: batch.length - sent };
}
__name(flushEmails, "flushEmails");
async function handleRequest(request, env, dependencies = {}) {
  const fetcher = dependencies.fetch || fetch;
  const db = dependencies.db || createDatabase(env, fetcher);
  const adminDb = dependencies.adminDb || createAdminDatabase(env, fetcher);
  const requestId = crypto.randomUUID();
  let verifiedActor = null;
  const publicRead = request.method === "GET" && /^\/api\/(home|products|product|categories|summits|events|event|articles|article|search|settings|policy)$/.test(new URL(request.url).pathname);
  let cookieHeaders = [];
  const response = /* @__PURE__ */ __name2((data, status = 200) => {
    const headers = new Headers({ "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff", "Referrer-Policy": "no-referrer", "X-Request-ID": requestId, "X-Robots-Tag": "noindex" });
    for (const cookie of cookieHeaders) headers.append("Set-Cookie", cookie);
    if (publicRead && status === 200) headers.set("Cache-Control", "public, max-age=30");
    return new Response(JSON.stringify(data), { status, headers });
  }, "response");
  try {
    const u = new URL(request.url), route = u.pathname.replace(/^\/api\/?/, "").replace(/\/$/, "");
    if (route === "health" && request.method === "GET") return response({ service: "1751", configured: ["SUPABASE_URL", "SUPABASE_ANON_KEY", "SUPABASE_SERVICE_ROLE_KEY", "APP_SECRET"].every((k) => !!env[k]), payment_mode: "sandbox" });
    if (route === "payments/webhook") {
      if (request.method !== "POST") fail2("method_not_allowed", 405);
      sandbox(env);
      const raw = await readBody(request, 128e3);
      if (!equal(request.headers.get("x-paystack-signature"), await hmac(env.PAYSTACK_SECRET_KEY, raw, "SHA-512"))) fail2("invalid_signature", 401);
      const event = parseBody(raw);
      if (event.event === "charge.success") await verifyPayment(text(event.data?.reference, 1, 100), env, fetcher, db);
      else if (event.event === "refund.processed") {
        const refund = await paystack(env, fetcher, `refund/${encodeURIComponent(text(String(event.data?.id || ""), 1, 100))}`);
        if (refund.status !== "processed" || refund.transaction?.domain !== "test" || !refund.transaction?.reference || !Number.isSafeInteger(refund.amount)) fail2("payment_mismatch", 409);
        await db("refund", { reference: refund.transaction.reference, amount: refund.amount, provider_id: String(refund.id) });
      }
      return response({ received: true });
    }
    if (route.startsWith("jobs/")) {
      if (request.method !== "POST") fail2("method_not_allowed", 405);
      requireConfig(env, "JOB_SECRET");
      if (env.JOB_SECRET.length < 32 || !equal(request.headers.get("Authorization"), `Bearer ${env.JOB_SECRET}`)) fail2("unauthorized", 401);
      if (route === "jobs/email") {
        const result = await flushEmails(env, fetcher, db);
        await db("operation_report", { kind: "email", status: result.failed ? "failed" : "ok", details: result });
        return response(result);
      }
      if (route === "jobs/reconcile") {
        sandbox(env);
        const references = await db("pending_payments");
        let verified = 0, failed = 0;
        for (const reference of references) {
          try {
            await verifyPayment(reference, env, fetcher, db);
            verified++;
          } catch {
            failed++;
          }
        }
        const result = { checked: references.length, verified, failed };
        await db("operation_report", { kind: "reconcile", status: failed ? "failed" : "ok", details: result });
        return response(result);
      }
      if (route === "jobs/monitor") {
        const result = await db("monitor", { ops_inbox: env.OPS_INBOX ? email(env.OPS_INBOX) : null });
        await db("operation_report", { kind: "health", status: result.healthy ? "ok" : "failed", details: result });
        return response(result);
      }
      if (route === "jobs/report") {
        const b2 = parseBody(await readBody(request));
        const kind = option(b2.kind, ["backup", "restore", "health"]);
        const details = { artifact_sha256: b2.artifact_sha256 ? token(b2.artifact_sha256) : null, encrypted: b2.encrypted === true, verified: b2.verified === true, error_code: b2.error_code ? text(b2.error_code, 1, 100) : null };
        await db("operation_report", { kind, status: option(b2.status, ["ok", "failed"]), details });
        return response({ recorded: true });
      }
      fail2("not_found", 404);
    }
    if (!["GET", "POST"].includes(request.method)) fail2("method_not_allowed", 405);
    if (request.method === "POST") checkMutation(request, env);
    requireConfig(env, "APP_SECRET");
    if (env.APP_SECRET.length < 32) fail2("invalid_server_configuration", 503);
    const scope = request.method === "POST" ? route : "read";
    const ip = request.headers.get("CF-Connecting-IP") || "local";
    const rate = await db("rate", { bucket: await hmac(env.APP_SECRET, `${ip}:${scope}`), max: request.method === "POST" && route.startsWith("auth/") ? 15 : request.method === "POST" ? 30 : 180 });
    if (!rate.allowed) fail2("rate_limited", 429);
    const deferredUpload = route === "admin/upload" && request.method === "POST";
    let b = deferredUpload ? {} : request.method === "POST" ? parseBody(await readBody(request, route === "admin/save" ? 8e4 : 2e4)) : Object.fromEntries(u.searchParams);
    if (request.method === "GET") {
      for (const k of ["limit", "offset"]) if (b[k] != null && (!/^\d{1,6}$/.test(b[k]) || Number(b[k]) > 1e4)) fail2("invalid_pagination");
      if (b.q != null) b.q = text(b.q, 0, 100);
      for (const k of ["id", "community_id", "summit_id", "category_id"]) if (b[k]) id(b[k]);
    }
    if (route.startsWith("auth/") && request.method === "POST") {
      const action = route.slice(5);
      if (["signup", "login", "recover"].includes(action)) {
        const address = email(b.email);
        if (action === "recover") {
          await authCall(env, fetcher, `recover?redirect_to=${encodeURIComponent(origin(env) + "/#account")}`, "POST", { email: address });
          return response({ accepted: true });
        }
        const password = text(b.password, 12, 128);
        const s = await authCall(env, fetcher, action === "signup" ? "signup" : "token?grant_type=password", "POST", {
          email: address,
          password,
          ...action === "signup" ? { data: { display_name: text(b.display_name, 2, 100) } } : {}
        });
        if (action === "signup") {
          if (s.access_token) fail2("email_verification_must_be_enabled", 503);
          return response({ verification_required: true });
        }
        if (!s.user?.email_confirmed_at) fail2("email_verification_required", 403);
        cookieHeaders = sessionCookies(s, env);
        return response({ user: safeUser(s.user) });
      }
      if (action === "verify") {
        const s = await authCall(env, fetcher, "verify", "POST", { token_hash: text(b.token_hash, 20, 200), type: option(b.type, ["signup", "recovery", "email_change"]) });
        cookieHeaders = sessionCookies(s, env);
        return response({ user: safeUser(s.user), recovery: b.type === "recovery" });
      }
    }
    const session = publicRead ? { user: null, cookieHeaders: [] } : await identity(request, env, fetcher);
    cookieHeaders = session.cookieHeaders;
    const user = session.user, actor = user?.id || null;
    verifiedActor = actor;
    const claims = validatedClaims(session.bearer || "");
    const primaryTimes = (claims.amr || []).filter((x) => x.method !== "totp").map((x) => Number(x.timestamp)).filter(Number.isFinite);
    const sessionId = claims.session_id || await hash(session.bearer || "anonymous");
    if (actor && route !== "auth/logout") await db("account_access", { session_id: sessionId, issued_at: primaryTimes.length ? Math.min(...primaryTimes) : claims.iat || 0 }, actor);
    const authenticated = /* @__PURE__ */ __name2(() => {
      if (!user?.email_confirmed_at) fail2("unauthorized", 401);
      return actor;
    }, "authenticated");
    if (route === "auth/session" && request.method === "GET") return response({ user: user ? safeUser(user) : null });
    if (route === "auth/logout" && request.method === "POST") {
      let remoteRevoked = true;
      if (actor) await db("session_revoke", { session_id: sessionId }, actor).catch(() => {
        remoteRevoked = false;
      });
      if (session.bearer) await authCall(env, fetcher, "logout", "POST", null, session.bearer).catch(() => {
        remoteRevoked = false;
      });
      cookieHeaders = sessionCookies(null, env);
      return response({ logged_out: true, remote_revoked: remoteRevoked });
    }
    if (route === "auth/password" && request.method === "POST") {
      authenticated();
      await authCall(env, fetcher, "user", "PUT", { password: text(b.password, 12, 128) }, session.bearer);
      return response({ changed: true });
    }
    if (route.startsWith("admin/")) {
      if (deferredUpload) {
        const c = await adminDb("context", {}, actor, isMfa(claims));
        if (!isMfa(claims) || !c.permissions.some((v) => ["products", "content", "events", "settings"].includes(v))) fail2("forbidden", 403);
        b = parseBody(await readBody(request, 12e6));
      }
      const context = { route, b, request, env, fetcher, db, adminDb, session, cookieHeaders, requestId };
      const result = route === "admin/upload" || route === "admin/scan" ? await handleUpload(context) : await handleAdmin(context);
      return result instanceof Response ? result : response(result);
    }
    if (route === "reports" && request.method === "GET") return response((await adminDb("reports", { ...b, request_id: requestId }, actor, isMfa(claims))).rows);
    if (route === "moderation" && request.method === "POST") return response(await adminDb("moderate", { id: id(b.id), decision: b.hide === true ? "hide" : "dismiss", note: "", request_id: requestId }, actor, isMfa(claims)));
    if (route === "registrations/check-in" && request.method === "POST") return response(await adminDb("registration_action", { reference: text(b.reference, 5, 100), operation: "check_in", request_id: requestId }, actor, isMfa(claims)));
    if (route === "settings" && request.method === "GET") return response(await db("public_settings"));
    if (route === "home" && request.method === "GET") return response(await db("home_content"));
    if (route === "policy" && request.method === "GET") return response(await db("public_policy", { slug: option(b.slug, ["privacy", "terms", "cookies", "refunds", "digital-delivery", "community-guidelines", "event-terms"]) }));
    const reads = { products: "products", product: "product", categories: "categories", summits: "summits", events: "events", event: "event", articles: "articles", article: "article", search: "search", communities: "communities", posts: "posts", post: "post", dashboard: "dashboard", cart: "cart", reports: "reports" };
    if (reads[route] && request.method === "GET") {
      if (["dashboard", "cart", "reports"].includes(route)) authenticated();
      return response(await db(reads[route], b, actor));
    }
    if (route === "inquiries" && request.method === "POST") {
      requireConfig(env, "TEAM_INBOX");
      consent(b);
      if (b.website) fail2("invalid_input");
      return response(await db("inquiry", { key: id(b.key), name: text(b.name, 2, 100), email: email(b.email), organization: b.organization ? text(b.organization, 0, 150) : "", type: option(b.type, ["project", "training", "partnership", "general"]), message: text(b.message, 10, 5e3), budget: b.budget ? text(b.budget, 0, 100) : "", contact_method: option(b.contact_method, ["email", "phone"]), phone: b.contact_method === "phone" ? text(b.phone, 7, 30) : "", team_inbox: email(env.TEAM_INBOX) }));
    }
    if (route === "newsletter/subscribe" && request.method === "POST") {
      consent(b);
      if (b.website) fail2("invalid_input");
      const confirm = hex(crypto.getRandomValues(new Uint8Array(32))), unsub = hex(crypto.getRandomValues(new Uint8Array(32)));
      await db("newsletter", { email: email(b.email), token_hash: await hash(confirm), unsubscribe_hash: await hash(unsub), confirm_url: `${origin(env)}/#newsletter/confirm/${confirm}`, unsubscribe_url: `${origin(env)}/#newsletter/unsubscribe/${unsub}` });
      return response({ accepted: true, message: "If needed, a confirmation email has been queued. Your subscription becomes active only after confirmation." });
    }
    if (["newsletter/confirm", "newsletter/unsubscribe"].includes(route) && request.method === "POST") return response(await db(route.endsWith("confirm") ? "newsletter_confirm" : "newsletter_unsubscribe", { token_hash: await hash(token(b.token)) }));
    if (route === "checkout" && request.method === "POST") {
      sandbox(env);
      const items = validateItems(b.items), key = id(b.key), address = user ? user.email.toLowerCase() : email(b.email);
      const promotion = b.promotion ? text(b.promotion, 1, 50).toUpperCase() : "";
      const accessToken = await hmac(env.APP_SECRET, `order:${address}:${key}`);
      const ord = await db("checkout", { key, items, email: address, name: text(b.name, 2, 100), promotion, access_hash: await hash(accessToken), fingerprint: await hash(JSON.stringify({ items, promotion })) }, actor);
      await db("receipt_url", { reference: ord.reference, url: `${origin(env)}/#order/${ord.reference}/${accessToken}` });
      const full = await db("order", { reference: ord.reference, access_hash: await hash(accessToken) }, actor);
      let initialized;
      try {
        initialized = await initializePayment(full, env, fetcher, db);
      } catch (e) {
        throw new ApiError(e instanceof ApiError ? e.code : "payment_provider_unavailable", e instanceof ApiError ? e.status : 502, { order: { reference: ord.reference, total_minor: ord.total_minor, access_token: accessToken } });
      }
      return response({ reference: ord.reference, total_minor: ord.total_minor, checkout_url: initialized.checkout_url, status: initialized.status, access_token: accessToken });
    }
    if (route === "orders" && request.method === "POST") {
      const p = { reference: text(b.reference, 5, 100), ...b.access_token ? { access_hash: await hash(token(b.access_token)) } : {} };
      return response(await db("order", p, actor));
    }
    if (route === "payments/verify" && request.method === "POST") {
      const reference = text(b.reference, 5, 100);
      await db("order", { reference, ...b.access_token ? { access_hash: await hash(token(b.access_token)) } : {} }, actor);
      return response(await verifyPayment(reference, env, fetcher, db));
    }
    if (route === "payments/retry" && request.method === "POST") {
      const ord = await db("order", { reference: text(b.reference, 5, 100), ...b.access_token ? { access_hash: await hash(token(b.access_token)) } : {} }, actor);
      return response(await initializePayment(ord, env, fetcher, db));
    }
    if (route === "downloads" && request.method === "POST") {
      const asset = await db("download", { reference: text(b.reference, 5, 100), asset_id: id(b.asset_id), ...b.access_token ? { access_hash: await hash(token(b.access_token)) } : {} }, actor);
      try {
        if (asset.path.split("/").includes("..") || asset.path.startsWith("/")) fail2("storage_unavailable", 502);
        const { response: upstream, data } = await fetchJson(fetcher, `${supabase(env)}/storage/v1/object/sign/digital-products/${asset.path.split("/").map(encodeURIComponent).join("/")}`, {
          method: "POST",
          headers: { Authorization: `Bearer ${env.SUPABASE_SERVICE_ROLE_KEY}`, "Content-Type": "application/json" },
          body: JSON.stringify({ expiresIn: 60 })
        }, "storage_unavailable");
        if (!upstream.ok || !data.signedURL?.startsWith("/object/sign/digital-products/")) fail2("storage_unavailable", 502);
        return response({ url: `${supabase(env)}/storage/v1${data.signedURL}`, expires_in: 60 });
      } catch (e) {
        await db("download_failed", { id: asset.reservation_id });
        throw e;
      }
    }
    if (route === "registrations" && request.method === "POST") {
      authenticated();
      const sessionId2 = id(b.session_id);
      const events = await db("event", { id: sessionId2 }, actor);
      if (!events.length) fail2("not_found", 404);
      if (events[0].price_minor > 0) sandbox(env);
      const reg = await db("register", { session_id: sessionId2, name: text(b.name, 2, 100), email: user.email.toLowerCase(), access_hash: await hash(crypto.randomUUID()) }, actor);
      if (reg.order_reference) {
        const ord = await db("order", { reference: reg.order_reference }, actor);
        return response({ ...reg, checkout_url: (await initializePayment(ord, env, fetcher, db)).checkout_url });
      }
      return response(reg);
    }
    const writes = {
      profile: ["profile", () => ({ display_name: text(b.display_name, 2, 100), avatar_url: b.avatar_url ? validImage(b.avatar_url) : "" })],
      "account/delete-request": ["delete_request", () => {
        requireConfig(env, "TEAM_INBOX");
        return { team_inbox: email(env.TEAM_INBOX) };
      }],
      cart: ["cart_save", () => ({ items: Array.isArray(b.items) && b.items.length === 0 ? [] : validateItems(b.items) })],
      "registrations/cancel": ["registration_cancel", () => ({ id: id(b.id) })],
      memberships: ["membership", () => ({ community_id: id(b.community_id), join: typeof b.join === "boolean" ? b.join : fail2("invalid_input") })],
      "posts/create": ["post_create", () => ({ community_id: id(b.community_id), category_id: b.category_id ? id(b.category_id) : null, title: text(b.title, 3, 180), body: text(b.body, 3, 1e4) })],
      "posts/update": ["post_update", () => ({ id: id(b.id), category_id: b.category_id ? id(b.category_id) : null, title: text(b.title, 3, 180), body: text(b.body, 3, 1e4) })],
      "posts/delete": ["post_delete", () => ({ id: id(b.id) })],
      "comments/create": ["comment_create", () => ({ post_id: id(b.post_id), parent_id: b.parent_id ? id(b.parent_id) : null, body: text(b.body, 2, 5e3) })],
      "comments/update": ["comment_update", () => ({ id: id(b.id), body: text(b.body, 2, 5e3) })],
      "comments/delete": ["comment_delete", () => ({ id: id(b.id) })],
      reports: ["report", () => b.comment_id ? { comment_id: id(b.comment_id), reason: text(b.reason, 5, 1e3) } : { post_id: id(b.post_id), reason: text(b.reason, 5, 1e3) }],
      moderation: ["moderate", () => ({ id: id(b.id), hide: typeof b.hide === "boolean" ? b.hide : fail2("invalid_input") })],
      "registrations/check-in": ["check_in", () => ({ reference: text(b.reference, 5, 100) })]
    };
    if (writes[route] && request.method === "POST") {
      authenticated();
      const [action, validate] = writes[route];
      return response(await db(action, validate(), actor));
    }
    fail2("not_found", 404);
  } catch (e) {
    if (new URL(request.url).pathname.startsWith("/api/admin/") && e instanceof ApiError && [401, 403].includes(e.status)) {
      const event = { request_id: requestId, code: e.code, route: "/api/admin" };
      await db("security_event", event, verifiedActor).catch(() => {
      });
    }
    if ((e instanceof ApiError ? e.status : 500) >= 500) {
      const incident = { request_id: requestId, code: e instanceof ApiError ? e.code : "internal_error", route: new URL(request.url).pathname };
      console.error(JSON.stringify({ event: "request_failed", ...incident }));
      const record = db("incident", incident).catch(() => {
      });
      if (dependencies.waitUntil) dependencies.waitUntil(record);
      else await record;
    }
    return response({ error: e instanceof ApiError ? e.code : "internal_error", ...e instanceof ApiError && e.details ? e.details : {} }, e instanceof ApiError ? e.status : 500);
  }
}
__name(handleRequest, "handleRequest");
function validImage(value) {
  const v = text(value, 1, 1e3);
  try {
    const u = new URL(v);
    if (u.protocol !== "https:") fail2("invalid_image_url");
    return u.href;
  } catch {
    fail2("invalid_image_url");
  }
}
__name(validImage, "validImage");
var UUID;
var TOKEN;
var encoder;
var ApiError;
var fail2;
var requireConfig;
var id;
var email;
var option;
var consent;
var token;
var hex;
var hash;
var dbCodes;
var safeUser;
var escape;
var init_api = __esm({
  "../backend/api.js"() {
    init_functionsRoutes_0_7395176389100484();
    init_admin();
    init_uploads();
    UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
    TOKEN = /^[a-f0-9]{64}$/;
    encoder = new TextEncoder();
    ApiError = class extends Error {
      static {
        __name(this, "ApiError");
      }
      static {
        __name2(this, "ApiError");
      }
      constructor(code, status = 400, details) {
        super(code);
        this.code = code;
        this.status = status;
        this.details = details;
      }
    };
    fail2 = /* @__PURE__ */ __name2((code, status) => {
      throw new ApiError(code, status);
    }, "fail");
    requireConfig = /* @__PURE__ */ __name2((env, ...keys) => {
      if (keys.some((k) => !env[k])) fail2("service_not_configured", 503);
    }, "requireConfig");
    __name2(text, "text");
    id = /* @__PURE__ */ __name2((v) => UUID.test(v || "") ? v : fail2("invalid_id"), "id");
    email = /* @__PURE__ */ __name2((v) => {
      v = text(v, 3, 254).toLowerCase();
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v)) fail2("invalid_email");
      return v;
    }, "email");
    option = /* @__PURE__ */ __name2((v, choices) => choices.includes(v) ? v : fail2("invalid_input"), "option");
    consent = /* @__PURE__ */ __name2((b) => b.consent === true ? true : fail2("consent_required"), "consent");
    token = /* @__PURE__ */ __name2((v) => TOKEN.test(v || "") ? v : fail2("invalid_token"), "token");
    hex = /* @__PURE__ */ __name2((buffer) => [...new Uint8Array(buffer)].map((x) => x.toString(16).padStart(2, "0")).join(""), "hex");
    hash = /* @__PURE__ */ __name2(async (v) => hex(await crypto.subtle.digest("SHA-256", encoder.encode(v))), "hash");
    __name2(hmac, "hmac");
    __name2(equal, "equal");
    __name2(validateItems, "validateItems");
    __name2(origin, "origin");
    __name2(checkMutation, "checkMutation");
    __name2(readBody, "readBody");
    __name2(parseBody, "parseBody");
    __name2(fetchJson, "fetchJson");
    __name2(supabase, "supabase");
    dbCodes = /* @__PURE__ */ new Set(["forbidden", "unauthorized", "not_found", "conflict", "invalid_cart", "unavailable_product", "invalid_quantity", "invalid_promotion", "invalid_total", "payment_mismatch", "duplicate_payment", "partial_refund_requires_review", "registration_closed", "capacity_full", "cancellation_closed", "paid_cancellation_requires_review", "joining_closed", "invalid_category", "invalid_parent", "invalid_or_expired", "download_limit", "physical_fulfillment_not_configured", "unavailable_product_asset", "mfa_required", "session_revoked", "account_suspended", "maintenance_mode"]);
    __name2(createDatabase, "createDatabase");
    __name2(cookies, "cookies");
    __name2(sessionCookies, "sessionCookies");
    safeUser = /* @__PURE__ */ __name2((user) => ({ id: user.id, email: user.email, verified: !!user.email_confirmed_at, display_name: user.user_metadata?.display_name || "", created_at: user.created_at }), "safeUser");
    __name2(authCall, "authCall");
    __name2(identity, "identity");
    __name2(sandbox, "sandbox");
    __name2(paystack, "paystack");
    __name2(verifyPayment, "verifyPayment");
    __name2(initializePayment, "initializePayment");
    escape = /* @__PURE__ */ __name2((s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]), "escape");
    __name2(renderEmail, "renderEmail");
    __name2(flushEmails, "flushEmails");
    __name2(handleRequest, "handleRequest");
    __name2(validImage, "validImage");
  }
});
function onRequest({ request, env, waitUntil }) {
  return handleRequest(request, env, { waitUntil });
}
__name(onRequest, "onRequest");
var init_path = __esm({
  "api/[[path]].js"() {
    init_functionsRoutes_0_7395176389100484();
    init_api();
    __name2(onRequest, "onRequest");
  }
});
function contentSecurityPolicy() {
  return "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com; img-src 'self' https:; connect-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'";
}
__name(contentSecurityPolicy, "contentSecurityPolicy");
var init_security = __esm({
  "../scripts/security.mjs"() {
    init_functionsRoutes_0_7395176389100484();
    __name2(contentSecurityPolicy, "contentSecurityPolicy");
  }
});
function routeFromPath(path) {
  if (path === "/") return "home";
  if (["/store", "/summit", "/community", "/about", "/account"].includes(path)) return path.slice(1);
  if (path === "/stories") return "home";
  if (path.startsWith("/stories/")) return "story/" + path.slice(9);
  if (path.startsWith("/products/")) return "product/" + path.split("/")[2];
  if (path.startsWith("/events/")) return "event/" + path.split("/")[2];
  if (path.startsWith("/community/discussion/")) return "discussion/" + path.split("/")[3];
  if (path.startsWith("/community/posts/")) return "post/" + path.split("/")[3];
  return null;
}
__name(routeFromPath, "routeFromPath");
function card(p) {
  return `<article class="product"><div class="product-image">${image(p.image_url) ? `<img loading="lazy" src="${escape2(p.image_url)}" alt="${escape2(p.title)}">` : '<div class="fake-cover">1751</div>'}</div><div class="product-body"><small>${escape2(p.category || "Resources")}</small><h3><a href="${publicPath("products", p)}">${escape2(p.title)}</a></h3><p>${escape2(p.description)}</p><div class="price">${minor(p.price_minor)}</div><a class="btn sm" href="${publicPath("products", p)}">Details</a></div></article>`;
}
__name(card, "card");
async function renderPublic(request, env, { template, db = createDatabase(env, fetch) } = {}) {
  const url = new URL(request.url), path = url.pathname.replace(/\/$/, "") || "/";
  const privatePage = path === "/account" || path.startsWith("/community/discussion/") || path.startsWith("/community/posts/");
  const indexed = env.PUBLIC_INDEXING_ENABLED === "true" && !privatePage;
  const headers = new Headers({ "Content-Type": "text/html; charset=utf-8", "Cache-Control": privatePage ? "no-store" : "public, max-age=30", "X-Content-Type-Options": "nosniff", "Referrer-Policy": "strict-origin-when-cross-origin", "Content-Security-Policy": contentSecurityPolicy(), "Permissions-Policy": "camera=(), microphone=(), geolocation=()" });
  if (!indexed) headers.set("X-Robots-Tag", "noindex, nofollow");
  if (env.HTTPS_VERIFIED === "true" && url.protocol === "https:") headers.set("Strict-Transport-Security", "max-age=31536000");
  const origin2 = new URL(env.APP_ORIGIN || url.origin).origin;
  if (path === "/robots.txt") return new Response(indexed ? `User-agent: *
Disallow: /admin
Disallow: /account
Disallow: /api
Disallow: /community/discussion
Disallow: /community/posts
Sitemap: ${origin2}/sitemap.xml
` : "User-agent: *\nDisallow: /\n", { headers: { "Content-Type": "text/plain", "Cache-Control": "public, max-age=60" } });
  try {
    if (path === "/sitemap.xml") {
      if (!indexed) return new Response("Indexing is disabled for this environment.", { status: 404, headers: { "X-Robots-Tag": "noindex" } });
      const routes2 = ["/", "/store", "/summit", "/community", "/about", "/stories"];
      for (const action of ["products", "events", "articles"]) for (let offset = 0; offset <= 1e4; offset += 50) {
        const list = await db(action, { limit: 50, offset });
        if (offset === 1e4 && list.length) throw new Error("sitemap_limit");
        for (const r of list) routes2.push(action === "articles" ? "/stories/" + r.slug : publicPath(action, r));
        if (list.length < 50) break;
      }
      for (const slug of ["privacy", "terms", "cookies", "refunds", "digital-delivery", "community-guidelines", "event-terms"]) if (await db("public_policy", { slug })) routes2.push("/legal/" + slug);
      return new Response(`<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">${routes2.map((r) => `<url><loc>${escape2(origin2 + r)}</loc></url>`).join("")}</urlset>`, { headers: { "Content-Type": "application/xml", "Cache-Control": "public, max-age=60" } });
    }
    if (path.startsWith("/legal/")) {
      const slug = path.slice(7);
      if (!["privacy", "terms", "cookies", "refunds", "digital-delivery", "community-guidelines", "event-terms"].includes(slug)) return new Response("Not found", { status: 404 });
      const policy = await db("public_policy", { slug });
      if (!policy) {
        headers.set("X-Robots-Tag", "noindex");
        headers.set("Cache-Control", "no-store");
        return new Response(simple("Policy pending approval", "This policy has not been approved by the responsible business/legal personnel. Contact the site owner for availability."), { status: 503, headers });
      }
      return new Response(simple(policy.title, policy.body, origin2 + path, indexed), { headers });
    }
    const route = routeFromPath(path);
    if (!route) return null;
    let title = "1751 \u2014 Digitizing Africa", description = "1751 connects technology, creativity, knowledge and opportunity.", canonical = origin2 + path, structured = null, detail = null, page = route.split("/")[0], cover = origin2 + "/assets/img7.webp";
    if (route.startsWith("product/")) {
      const p = (await db("product", { id: route.slice(8) }))[0];
      if (!p) return new Response("Product unavailable", { status: 404, headers: { "X-Robots-Tag": "noindex" } });
      const target = publicPath("products", p);
      if (path !== target) return Response.redirect(origin2 + target, 301);
      page = "story";
      title = p.title + " \u2014 1751 Store";
      description = p.description.slice(0, 160);
      cover = image(p.image_url) ? new URL(p.image_url, origin2).href : cover;
      detail = `<article class="article-layout"><a href="/store">\u2190 Store</a><h1>${escape2(p.title)}</h1>${image(p.image_url) ? `<img class="article-cover" src="${escape2(p.image_url)}" alt="${escape2(p.title)}">` : ""}<p class="article-body">${escape2(p.description)}</p><p class="price">${minor(p.price_minor)}</p><button class="btn" data-action="add" data-id="${p.id}">Add to cart</button></article>`;
      structured = { "@context": "https://schema.org", "@type": "Product", name: p.title, description: p.description, image: cover, offers: { "@type": "Offer", priceCurrency: "NGN", price: p.price_minor / 100, url: canonical } };
    } else if (route.startsWith("story/")) {
      const a = (await db("article", { slug: route.slice(6) }))[0];
      if (!a) return new Response("Story unavailable", { status: 404, headers: { "X-Robots-Tag": "noindex" } });
      page = "story";
      title = a.title + " \u2014 1751";
      description = a.excerpt || a.body.slice(0, 160);
      cover = image(a.cover_image) ? new URL(a.cover_image, origin2).href : cover;
      detail = `<article class="article-layout"><a href="/stories">\u2190 Stories</a><h1>${escape2(a.title)}</h1><p>${escape2(a.author)} \xB7 ${escape2(a.published_at)} \xB7 ${a.reading_minutes} min read</p>${image(a.cover_image) ? `<img class="article-cover" src="${escape2(a.cover_image)}" alt="${escape2(a.title)}">` : ""}<div class="article-body">${escape2(a.body)}</div></article>`;
      structured = { "@context": "https://schema.org", "@type": "Article", headline: a.title, datePublished: a.published_at, author: { "@type": "Person", name: a.author }, image: cover, mainEntityOfPage: canonical };
    } else if (route.startsWith("event/")) {
      const e = (await db("event", { id: route.slice(6) }))[0];
      if (!e) return new Response("Event unavailable", { status: 404, headers: { "X-Robots-Tag": "noindex" } });
      const target = publicPath("events", e);
      if (path !== target) return Response.redirect(origin2 + target, 301);
      page = "story";
      title = e.title + " \u2014 1751 Summit";
      description = e.description.slice(0, 160);
      detail = `<article class="article-layout"><a href="/summit">\u2190 Summit</a><h1>${escape2(e.title)}</h1><p class="article-body">${escape2(e.description)}</p><p>${escape2(e.starts_at)} \u2013 ${escape2(e.ends_at)} \xB7 ${escape2(e.timezone)}</p><p>${escape2(e.location || "Location released on confirmation")} \xB7 ${e.price_minor ? minor(e.price_minor) : "Free"}</p><button class="btn" data-action="register-event" data-id="${e.id}">View registration availability</button></article>`;
      structured = { "@context": "https://schema.org", "@type": "Event", name: e.title, startDate: e.starts_at, endDate: e.ends_at, url: canonical, description: e.description };
    } else if (!privatePage) {
      title = { store: "1751 Store \u2014 Products and resources", summit: "1751 Summit \u2014 Programmes and events", community: "1751 Community \u2014 Learn, share, build", about: "About 1751 \u2014 Services and collaboration" }[page] || title;
    }
    let html = template;
    if (!html) throw new Error("template_missing");
    html = html.replace(/<title>.*?<\/title>/s, `<title>${escape2(title)}</title>`).replace(/<meta[^>]*name="description"[^>]*>/, `<meta name="description" content="${escape2(description)}">`);
    html = html.replace("</head>", `<meta name="1751-route" content="${escape2(route)}"><meta name="robots" content="${indexed ? "index,follow" : "noindex,nofollow"}"><link rel="canonical" href="${escape2(canonical)}"><meta property="og:title" content="${escape2(title)}"><meta property="og:description" content="${escape2(description)}"><meta property="og:url" content="${escape2(canonical)}"><meta property="og:image" content="${escape2(cover)}"><meta property="og:type" content="${structured?.["@type"] === "Article" ? "article" : "website"}"><meta name="twitter:card" content="summary_large_image">${structured ? `<script type="application/ld+json">${jsonLd(structured)}<\/script>` : ""}</head>`);
    html = html.replace(`class="page" id="page-${page}"`, `class="page active" id="page-${page}"`);
    if (detail) html = html.replace('<div class="container" id="article-content"></div>', `<div class="container" id="article-content">${detail}</div>`);
    if (!detail && !privatePage) {
      if (page === "home" || page === "store") {
        const products = await db("products", { limit: page === "store" ? 20 : 4 });
        html = html.replace(`<div class="products" id="${page === "store" ? "storeproducts" : "homeproducts"}"></div>`, `<div class="products" id="${page === "store" ? "storeproducts" : "homeproducts"}">${products.map(card).join("") || "<p>No approved products are published yet.</p>"}</div>`);
      }
      if (page === "home") {
        const articles = await db("articles", { limit: 12 });
        html = html.replace('<div class="story-grid" id="stories-list"></div>', `<div class="story-grid" id="stories-list">${articles.map((a) => `<article class="story"><div><span class="eyebrow">${escape2(a.category)}</span><h3><a href="/stories/${escape2(a.slug)}">${escape2(a.title)}</a></h3><p>${escape2(a.excerpt)}</p></div></article>`).join("") || "<p>No approved stories are published yet.</p>"}</div>`);
      }
      if (page === "summit") {
        const events = await db("events", { limit: 50 });
        html = html.replace('<div id="events"></div>', `<div id="events"><div class="event-list">${events.map((e) => `<article class="event"><div><h3><a href="${publicPath("events", e)}">${escape2(e.title)}</a></h3><p>${escape2(e.starts_at)} \xB7 ${escape2(e.timezone)}</p></div></article>`).join("") || "<p>No published sessions are available yet.</p>"}</div></div>`);
      }
    }
    html = html.replace(/(src|href)="(assets\/|bootstrap.js|stage[123]\.(?:css|js))/g, '$1="/$2');
    return new Response(html, { headers });
  } catch {
    headers.set("X-Robots-Tag", "noindex");
    headers.set("Cache-Control", "no-store");
    return new Response(simple("1751 is temporarily unavailable", "The content service could not be reached. Please retry shortly."), { status: 503, headers });
  }
}
__name(renderPublic, "renderPublic");
function simple(title, body, canonical = "", indexed = false) {
  return `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="${indexed ? "index,follow" : "noindex"}"><title>${escape2(title)} \u2014 1751</title>${canonical ? `<link rel="canonical" href="${escape2(canonical)}">` : ""}<link rel="stylesheet" href="/admin/admin.css"></head><body><header><a class="brand" href="/">1751</a></header><main><h1>${escape2(title)}</h1><div class="preformatted">${escape2(body)}</div></main></body></html>`;
}
__name(simple, "simple");
var escape2;
var jsonLd;
var minor;
var image;
var slugify;
var publicPath;
var init_render = __esm({
  "../backend/render.js"() {
    init_functionsRoutes_0_7395176389100484();
    init_api();
    init_security();
    escape2 = /* @__PURE__ */ __name2((s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]), "escape");
    jsonLd = /* @__PURE__ */ __name2((value) => JSON.stringify(value).replace(/</g, "\\u003c"), "jsonLd");
    minor = /* @__PURE__ */ __name2((n) => new Intl.NumberFormat("en-NG", { style: "currency", currency: "NGN" }).format(n / 100), "minor");
    image = /* @__PURE__ */ __name2((value) => /^https:\/\//.test(value || "") || /^assets\/img\d+\.webp$/.test(value || "") ? value : null, "image");
    slugify = /* @__PURE__ */ __name2((s) => String(s).toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 90) || "details", "slugify");
    publicPath = /* @__PURE__ */ __name2((kind, r) => `/${kind}/${r.id}/${slugify(r.title)}`, "publicPath");
    __name2(routeFromPath, "routeFromPath");
    __name2(card, "card");
    __name2(renderPublic, "renderPublic");
    __name2(simple, "simple");
  }
});
async function onRequest2({ request, env }) {
  const url = new URL(request.url);
  if (request.method !== "GET" && request.method !== "HEAD") return new Response("Method not allowed", { status: 405 });
  const templateResponse = await env.ASSETS.fetch(new Request(new URL("/index.html", url.origin), { method: "GET", headers: request.headers }));
  const rendered = await renderPublic(request, env, { template: await templateResponse.text() });
  return rendered || env.ASSETS.fetch(request);
}
__name(onRequest2, "onRequest2");
var init_path2 = __esm({
  "[[path]].js"() {
    init_functionsRoutes_0_7395176389100484();
    init_render();
    __name2(onRequest2, "onRequest");
  }
});
var routes;
var init_functionsRoutes_0_7395176389100484 = __esm({
  "../.wrangler/tmp/pages-pF3dTw/functionsRoutes-0.7395176389100484.mjs"() {
    init_path();
    init_path2();
    routes = [
      {
        routePath: "/api/:path*",
        mountPath: "/api",
        method: "",
        middlewares: [],
        modules: [onRequest]
      },
      {
        routePath: "/:path*",
        mountPath: "/",
        method: "",
        middlewares: [],
        modules: [onRequest2]
      }
    ];
  }
});
init_functionsRoutes_0_7395176389100484();
init_functionsRoutes_0_7395176389100484();
function lexer(str) {
  var tokens = [];
  var i = 0;
  while (i < str.length) {
    var char = str[i];
    if (char === "*" || char === "+" || char === "?") {
      tokens.push({ type: "MODIFIER", index: i, value: str[i++] });
      continue;
    }
    if (char === "\\") {
      tokens.push({ type: "ESCAPED_CHAR", index: i++, value: str[i++] });
      continue;
    }
    if (char === "{") {
      tokens.push({ type: "OPEN", index: i, value: str[i++] });
      continue;
    }
    if (char === "}") {
      tokens.push({ type: "CLOSE", index: i, value: str[i++] });
      continue;
    }
    if (char === ":") {
      var name = "";
      var j = i + 1;
      while (j < str.length) {
        var code = str.charCodeAt(j);
        if (
          // `0-9`
          code >= 48 && code <= 57 || // `A-Z`
          code >= 65 && code <= 90 || // `a-z`
          code >= 97 && code <= 122 || // `_`
          code === 95
        ) {
          name += str[j++];
          continue;
        }
        break;
      }
      if (!name)
        throw new TypeError("Missing parameter name at ".concat(i));
      tokens.push({ type: "NAME", index: i, value: name });
      i = j;
      continue;
    }
    if (char === "(") {
      var count = 1;
      var pattern = "";
      var j = i + 1;
      if (str[j] === "?") {
        throw new TypeError('Pattern cannot start with "?" at '.concat(j));
      }
      while (j < str.length) {
        if (str[j] === "\\") {
          pattern += str[j++] + str[j++];
          continue;
        }
        if (str[j] === ")") {
          count--;
          if (count === 0) {
            j++;
            break;
          }
        } else if (str[j] === "(") {
          count++;
          if (str[j + 1] !== "?") {
            throw new TypeError("Capturing groups are not allowed at ".concat(j));
          }
        }
        pattern += str[j++];
      }
      if (count)
        throw new TypeError("Unbalanced pattern at ".concat(i));
      if (!pattern)
        throw new TypeError("Missing pattern at ".concat(i));
      tokens.push({ type: "PATTERN", index: i, value: pattern });
      i = j;
      continue;
    }
    tokens.push({ type: "CHAR", index: i, value: str[i++] });
  }
  tokens.push({ type: "END", index: i, value: "" });
  return tokens;
}
__name(lexer, "lexer");
__name2(lexer, "lexer");
function parse(str, options) {
  if (options === void 0) {
    options = {};
  }
  var tokens = lexer(str);
  var _a = options.prefixes, prefixes = _a === void 0 ? "./" : _a, _b = options.delimiter, delimiter = _b === void 0 ? "/#?" : _b;
  var result = [];
  var key = 0;
  var i = 0;
  var path = "";
  var tryConsume = /* @__PURE__ */ __name2(function(type) {
    if (i < tokens.length && tokens[i].type === type)
      return tokens[i++].value;
  }, "tryConsume");
  var mustConsume = /* @__PURE__ */ __name2(function(type) {
    var value2 = tryConsume(type);
    if (value2 !== void 0)
      return value2;
    var _a2 = tokens[i], nextType = _a2.type, index = _a2.index;
    throw new TypeError("Unexpected ".concat(nextType, " at ").concat(index, ", expected ").concat(type));
  }, "mustConsume");
  var consumeText = /* @__PURE__ */ __name2(function() {
    var result2 = "";
    var value2;
    while (value2 = tryConsume("CHAR") || tryConsume("ESCAPED_CHAR")) {
      result2 += value2;
    }
    return result2;
  }, "consumeText");
  var isSafe = /* @__PURE__ */ __name2(function(value2) {
    for (var _i = 0, delimiter_1 = delimiter; _i < delimiter_1.length; _i++) {
      var char2 = delimiter_1[_i];
      if (value2.indexOf(char2) > -1)
        return true;
    }
    return false;
  }, "isSafe");
  var safePattern = /* @__PURE__ */ __name2(function(prefix2) {
    var prev = result[result.length - 1];
    var prevText = prefix2 || (prev && typeof prev === "string" ? prev : "");
    if (prev && !prevText) {
      throw new TypeError('Must have text between two parameters, missing text after "'.concat(prev.name, '"'));
    }
    if (!prevText || isSafe(prevText))
      return "[^".concat(escapeString(delimiter), "]+?");
    return "(?:(?!".concat(escapeString(prevText), ")[^").concat(escapeString(delimiter), "])+?");
  }, "safePattern");
  while (i < tokens.length) {
    var char = tryConsume("CHAR");
    var name = tryConsume("NAME");
    var pattern = tryConsume("PATTERN");
    if (name || pattern) {
      var prefix = char || "";
      if (prefixes.indexOf(prefix) === -1) {
        path += prefix;
        prefix = "";
      }
      if (path) {
        result.push(path);
        path = "";
      }
      result.push({
        name: name || key++,
        prefix,
        suffix: "",
        pattern: pattern || safePattern(prefix),
        modifier: tryConsume("MODIFIER") || ""
      });
      continue;
    }
    var value = char || tryConsume("ESCAPED_CHAR");
    if (value) {
      path += value;
      continue;
    }
    if (path) {
      result.push(path);
      path = "";
    }
    var open = tryConsume("OPEN");
    if (open) {
      var prefix = consumeText();
      var name_1 = tryConsume("NAME") || "";
      var pattern_1 = tryConsume("PATTERN") || "";
      var suffix = consumeText();
      mustConsume("CLOSE");
      result.push({
        name: name_1 || (pattern_1 ? key++ : ""),
        pattern: name_1 && !pattern_1 ? safePattern(prefix) : pattern_1,
        prefix,
        suffix,
        modifier: tryConsume("MODIFIER") || ""
      });
      continue;
    }
    mustConsume("END");
  }
  return result;
}
__name(parse, "parse");
__name2(parse, "parse");
function match(str, options) {
  var keys = [];
  var re = pathToRegexp(str, keys, options);
  return regexpToFunction(re, keys, options);
}
__name(match, "match");
__name2(match, "match");
function regexpToFunction(re, keys, options) {
  if (options === void 0) {
    options = {};
  }
  var _a = options.decode, decode = _a === void 0 ? function(x) {
    return x;
  } : _a;
  return function(pathname) {
    var m = re.exec(pathname);
    if (!m)
      return false;
    var path = m[0], index = m.index;
    var params = /* @__PURE__ */ Object.create(null);
    var _loop_1 = /* @__PURE__ */ __name2(function(i2) {
      if (m[i2] === void 0)
        return "continue";
      var key = keys[i2 - 1];
      if (key.modifier === "*" || key.modifier === "+") {
        params[key.name] = m[i2].split(key.prefix + key.suffix).map(function(value) {
          return decode(value, key);
        });
      } else {
        params[key.name] = decode(m[i2], key);
      }
    }, "_loop_1");
    for (var i = 1; i < m.length; i++) {
      _loop_1(i);
    }
    return { path, index, params };
  };
}
__name(regexpToFunction, "regexpToFunction");
__name2(regexpToFunction, "regexpToFunction");
function escapeString(str) {
  return str.replace(/([.+*?=^!:${}()[\]|/\\])/g, "\\$1");
}
__name(escapeString, "escapeString");
__name2(escapeString, "escapeString");
function flags(options) {
  return options && options.sensitive ? "" : "i";
}
__name(flags, "flags");
__name2(flags, "flags");
function regexpToRegexp(path, keys) {
  if (!keys)
    return path;
  var groupsRegex = /\((?:\?<(.*?)>)?(?!\?)/g;
  var index = 0;
  var execResult = groupsRegex.exec(path.source);
  while (execResult) {
    keys.push({
      // Use parenthesized substring match if available, index otherwise
      name: execResult[1] || index++,
      prefix: "",
      suffix: "",
      modifier: "",
      pattern: ""
    });
    execResult = groupsRegex.exec(path.source);
  }
  return path;
}
__name(regexpToRegexp, "regexpToRegexp");
__name2(regexpToRegexp, "regexpToRegexp");
function arrayToRegexp(paths, keys, options) {
  var parts = paths.map(function(path) {
    return pathToRegexp(path, keys, options).source;
  });
  return new RegExp("(?:".concat(parts.join("|"), ")"), flags(options));
}
__name(arrayToRegexp, "arrayToRegexp");
__name2(arrayToRegexp, "arrayToRegexp");
function stringToRegexp(path, keys, options) {
  return tokensToRegexp(parse(path, options), keys, options);
}
__name(stringToRegexp, "stringToRegexp");
__name2(stringToRegexp, "stringToRegexp");
function tokensToRegexp(tokens, keys, options) {
  if (options === void 0) {
    options = {};
  }
  var _a = options.strict, strict = _a === void 0 ? false : _a, _b = options.start, start = _b === void 0 ? true : _b, _c = options.end, end = _c === void 0 ? true : _c, _d = options.encode, encode = _d === void 0 ? function(x) {
    return x;
  } : _d, _e = options.delimiter, delimiter = _e === void 0 ? "/#?" : _e, _f = options.endsWith, endsWith = _f === void 0 ? "" : _f;
  var endsWithRe = "[".concat(escapeString(endsWith), "]|$");
  var delimiterRe = "[".concat(escapeString(delimiter), "]");
  var route = start ? "^" : "";
  for (var _i = 0, tokens_1 = tokens; _i < tokens_1.length; _i++) {
    var token2 = tokens_1[_i];
    if (typeof token2 === "string") {
      route += escapeString(encode(token2));
    } else {
      var prefix = escapeString(encode(token2.prefix));
      var suffix = escapeString(encode(token2.suffix));
      if (token2.pattern) {
        if (keys)
          keys.push(token2);
        if (prefix || suffix) {
          if (token2.modifier === "+" || token2.modifier === "*") {
            var mod = token2.modifier === "*" ? "?" : "";
            route += "(?:".concat(prefix, "((?:").concat(token2.pattern, ")(?:").concat(suffix).concat(prefix, "(?:").concat(token2.pattern, "))*)").concat(suffix, ")").concat(mod);
          } else {
            route += "(?:".concat(prefix, "(").concat(token2.pattern, ")").concat(suffix, ")").concat(token2.modifier);
          }
        } else {
          if (token2.modifier === "+" || token2.modifier === "*") {
            throw new TypeError('Can not repeat "'.concat(token2.name, '" without a prefix and suffix'));
          }
          route += "(".concat(token2.pattern, ")").concat(token2.modifier);
        }
      } else {
        route += "(?:".concat(prefix).concat(suffix, ")").concat(token2.modifier);
      }
    }
  }
  if (end) {
    if (!strict)
      route += "".concat(delimiterRe, "?");
    route += !options.endsWith ? "$" : "(?=".concat(endsWithRe, ")");
  } else {
    var endToken = tokens[tokens.length - 1];
    var isEndDelimited = typeof endToken === "string" ? delimiterRe.indexOf(endToken[endToken.length - 1]) > -1 : endToken === void 0;
    if (!strict) {
      route += "(?:".concat(delimiterRe, "(?=").concat(endsWithRe, "))?");
    }
    if (!isEndDelimited) {
      route += "(?=".concat(delimiterRe, "|").concat(endsWithRe, ")");
    }
  }
  return new RegExp(route, flags(options));
}
__name(tokensToRegexp, "tokensToRegexp");
__name2(tokensToRegexp, "tokensToRegexp");
function pathToRegexp(path, keys, options) {
  if (path instanceof RegExp)
    return regexpToRegexp(path, keys);
  if (Array.isArray(path))
    return arrayToRegexp(path, keys, options);
  return stringToRegexp(path, keys, options);
}
__name(pathToRegexp, "pathToRegexp");
__name2(pathToRegexp, "pathToRegexp");
var escapeRegex = /[.+?^${}()|[\]\\]/g;
function* executeRequest(request) {
  const requestPath = new URL(request.url).pathname;
  for (const route of [...routes].reverse()) {
    if (route.method && route.method !== request.method) {
      continue;
    }
    const routeMatcher = match(route.routePath.replace(escapeRegex, "\\$&"), {
      end: false
    });
    const mountMatcher = match(route.mountPath.replace(escapeRegex, "\\$&"), {
      end: false
    });
    const matchResult = routeMatcher(requestPath);
    const mountMatchResult = mountMatcher(requestPath);
    if (matchResult && mountMatchResult) {
      for (const handler of route.middlewares.flat()) {
        yield {
          handler,
          params: matchResult.params,
          path: mountMatchResult.path
        };
      }
    }
  }
  for (const route of routes) {
    if (route.method && route.method !== request.method) {
      continue;
    }
    const routeMatcher = match(route.routePath.replace(escapeRegex, "\\$&"), {
      end: true
    });
    const mountMatcher = match(route.mountPath.replace(escapeRegex, "\\$&"), {
      end: false
    });
    const matchResult = routeMatcher(requestPath);
    const mountMatchResult = mountMatcher(requestPath);
    if (matchResult && mountMatchResult && route.modules.length) {
      for (const handler of route.modules.flat()) {
        yield {
          handler,
          params: matchResult.params,
          path: matchResult.path
        };
      }
      break;
    }
  }
}
__name(executeRequest, "executeRequest");
__name2(executeRequest, "executeRequest");
var pages_template_worker_default = {
  async fetch(originalRequest, env, workerContext) {
    let request = originalRequest;
    const handlerIterator = executeRequest(request);
    let data = {};
    let isFailOpen = false;
    const next = /* @__PURE__ */ __name2(async (input, init) => {
      if (input !== void 0) {
        let url = input;
        if (typeof input === "string") {
          url = new URL(input, request.url).toString();
        }
        request = new Request(url, init);
      }
      const result = handlerIterator.next();
      if (result.done === false) {
        const { handler, params, path } = result.value;
        const context = {
          request: new Request(request.clone()),
          functionPath: path,
          next,
          params,
          get data() {
            return data;
          },
          set data(value) {
            if (typeof value !== "object" || value === null) {
              throw new Error("context.data must be an object");
            }
            data = value;
          },
          env,
          waitUntil: workerContext.waitUntil.bind(workerContext),
          passThroughOnException: /* @__PURE__ */ __name2(() => {
            isFailOpen = true;
          }, "passThroughOnException")
        };
        const response = await handler(context);
        if (!(response instanceof Response)) {
          throw new Error("Your Pages function should return a Response");
        }
        return cloneResponse(response);
      } else if ("ASSETS") {
        const response = await env["ASSETS"].fetch(request);
        return cloneResponse(response);
      } else {
        const response = await fetch(request);
        return cloneResponse(response);
      }
    }, "next");
    try {
      return await next();
    } catch (error2) {
      if (isFailOpen) {
        const response = await env["ASSETS"].fetch(request);
        return cloneResponse(response);
      }
      throw error2;
    }
  }
};
var cloneResponse = /* @__PURE__ */ __name2((response) => (
  // https://fetch.spec.whatwg.org/#null-body-status
  new Response(
    [101, 204, 205, 304].includes(response.status) ? null : response.body,
    response
  )
), "cloneResponse");

// sandbox-worker.js
var sandbox_worker_default = {
  async fetch(request, env, ctx) {
    const response = await pages_template_worker_default.fetch(request, { ...env, APP_ENV: "staging", PUBLIC_INDEXING_ENABLED: "false", HTTPS_VERIFIED: "false" }, ctx);
    const result = new Response(response.body, response);
    result.headers.set("X-Robots-Tag", "noindex, nofollow");
    return result;
  }
};
export {
  sandbox_worker_default as default
};
