var __defProp = Object.defineProperty;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });

// ../scripts/security.mjs
function contentSecurityPolicy() {
  return "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com; img-src 'self' https:; connect-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'";
}
__name(contentSecurityPolicy, "contentSecurityPolicy");

// worker.js
var publicPages = /* @__PURE__ */ new Set(["/", "/store", "/summit", "/community", "/about", "/account", "/stories"]);
var worker_default = {
  async fetch(request, env) {
    const url = new URL(request.url);
    const headers = { "X-Robots-Tag": "noindex, nofollow", "X-Content-Type-Options": "nosniff", "Referrer-Policy": "strict-origin-when-cross-origin", "Content-Security-Policy": contentSecurityPolicy(), "Permissions-Policy": "camera=(), microphone=(), geolocation=()" };
    const respond = /* @__PURE__ */ __name((body, status = 200, type = "text/plain; charset=utf-8") => new Response(request.method === "HEAD" ? null : body, { status, headers: { ...headers, "Content-Type": type, "Cache-Control": "no-store" } }), "respond");
    if (url.pathname === "/api/health") return respond(JSON.stringify({ service: "1751", mode: "visual-demo", configured: false, payment_mode: "disabled" }), 200, "application/json");
    if (url.pathname.startsWith("/api/")) return respond(JSON.stringify({ error: "demo_unavailable" }), 503, "application/json");
    if (!["GET", "HEAD"].includes(request.method)) return respond("Preview only. This action is unavailable.", 405);
    if (url.pathname === "/robots.txt") return respond("User-agent: *\nDisallow: /\n");
    if (url.pathname.startsWith("/legal/")) return respond("1751 preview: this policy is awaiting owner approval.", 503);
    if (url.pathname.startsWith("/products/") || url.pathname.startsWith("/events/") || url.pathname.startsWith("/stories/")) return respond("No published content is connected to this visual preview.", 404);
    const path = publicPages.has(url.pathname) ? "/index.html" : ["/admin", "/admin/"].includes(url.pathname) ? "/admin/index.html" : url.pathname;
    const response = await env.ASSETS.fetch(new Request(new URL(path, url.origin), request));
    const result = new Response(request.method === "HEAD" ? null : response.body, response);
    for (const [name, value] of Object.entries(headers)) result.headers.set(name, value);
    if (path.endsWith(".html") || path.startsWith("/admin/")) result.headers.set("Cache-Control", "no-store");
    return result;
  }
};
export {
  worker_default as default
};
//# sourceMappingURL=worker.js.map
