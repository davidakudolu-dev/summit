/* Explicitly disable data-backed actions in this static-only artifact. */
const previewFetch=window.fetch.bind(window);
window.fetch=(input,init)=>{const url=new URL(typeof input==='string'?input:input.url,location.href);if(url.origin===location.origin&&url.pathname.startsWith('/api/'))return Promise.resolve(new Response(JSON.stringify({error:'static_preview_only'}),{status:503,headers:{'Content-Type':'application/json'}}));return previewFetch(input,init);};
